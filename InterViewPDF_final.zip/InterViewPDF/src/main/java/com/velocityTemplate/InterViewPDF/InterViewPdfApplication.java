package com.velocityTemplate.InterViewPDF;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.kernel.events.PdfDocumentEvent;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfArray;
import com.itextpdf.kernel.pdf.PdfDictionary;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfName;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.AreaBreak;
import com.itextpdf.layout.element.IElement;

import com.itextpdf.kernel.utils.PdfMerger;
import com.itextpdf.kernel.events.Event;
import com.itextpdf.kernel.events.IEventHandler;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;



@SpringBootApplication
@EnableConfigurationProperties
@RestController
public class InterViewPdfApplication {

    public static void main(String[] args) {
        SpringApplication.run(InterViewPdfApplication.class, args);
    }

    @GetMapping("genpdf/{filename}")
	HttpEntity<byte[]>createPdf(
			@PathVariable("filename") String fileName)throws Exception {
        // Initialize Velocity Engine
		 List<Template> templates = new ArrayList<>();
		 
		 
		
        VelocityEngine velocityEngine = new VelocityEngine();
        
        velocityEngine.setProperty(RuntimeConstants.RESOURCE_LOADER,"classpath");
        velocityEngine.setProperty("classpath.resource.loader.class",
				ClasspathResourceLoader.class.getName());
        velocityEngine.init();

        // Create Velocity Context
        VelocityContext velocityContext = new VelocityContext();
        velocityContext.put("title", "Hello, World!");
        velocityContext.put("content", "This is a sample Velocity template converted to PDF using iTextPDF.");

        // Merge template with context
        StringWriter writer = new StringWriter();
//        Template template = velocityEngine.getTemplate("templates/helloWorld.vm");
        Template template1 = velocityEngine.getTemplate("templates/index.vm");
        Template template2 = velocityEngine.getTemplate("templates/page1.vm");
        Template template3 = velocityEngine.getTemplate("templates/page4.vm");
        Template template4 = velocityEngine.getTemplate("templates/page5.vm"); 
        Template template5 = velocityEngine.getTemplate("templates/page7.vm"); 
//        templates.add(template);
        templates.add(template1);
        templates.add(template2);
        templates.add(template3);
        templates.add(template4);
        templates.add(template5);
//        template.merge(velocityContext, writer);

        // Convert to PDF using iTextPDF
        PdfConverter converter = new PdfConverter();
//        byte[] pdfBytes = converter.convertToPdf(writer.toString());

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
//		baos = converter.convertToPdf(writer.toString());
		baos = createPdf(templates);
        
        HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_PDF);
		header.set(HttpHeaders.CONTENT_DISPOSITION,"attachment: filename=" + fileName.replace("", ""));
		header.setContentLength(baos.toByteArray().length);
        
        return new HttpEntity<byte[]>(baos.toByteArray(),header);
    }

    @Bean
    public PdfConverter pdfConverter() {
        return new PdfConverter();
    }
    
    
public ByteArrayOutputStream createPdf(List<Template> templates) throws IOException {
	 
	ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	ConverterProperties properties = new ConverterProperties();
	
    PdfWriter writer = new PdfWriter(outputStream);
    PdfDocument pdf = new PdfDocument(writer);

    PdfMerger merger = new PdfMerger(pdf);
    
    PageNumberEventHandler pageNumberEventHandler = new PageNumberEventHandler(pdf);

    pdf.addEventHandler(PdfDocumentEvent.END_PAGE,pageNumberEventHandler);
    
    Document document = new Document(pdf);

    for (Template template : templates) {
    	
    	VelocityContext context = new VelocityContext();

	        StringWriter w = new StringWriter();
	        template.merge(context, w);
	        String html1 = w.toString();
    
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PdfDocument temp = new PdfDocument(new PdfWriter(baos));
        HtmlConverter.convertToPdf(html1, temp, properties);
        
        
        temp = new PdfDocument(
            new PdfReader(new ByteArrayInputStream(baos.toByteArray())));
        merger.merge(temp, 1, temp.getNumberOfPages());
        temp.close();
    }
    pdf.close();
    
    String outputPath = "/home/mukesh/Documents/generated.pdf";
    FileOutputStream fos = new FileOutputStream(outputPath);
    fos.write(outputStream.toByteArray());
    fos.close();

    return outputStream;
	
	}
}

