package com.velocityTemplate.InterViewPDF;

import java.io.IOException;

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.events.Event;
import com.itextpdf.kernel.events.IEventHandler;
import com.itextpdf.kernel.events.PdfDocumentEvent;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfArray;
import com.itextpdf.kernel.pdf.PdfDictionary;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfName;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.kernel.pdf.PdfWriter;

public class PageNumberEventHandler implements IEventHandler {
	private final PdfDocument pdfDocument;
	private final PdfFont font;
	private final Image logoImage;

    public PageNumberEventHandler(PdfDocument pdfDocument) throws IOException{
        this.pdfDocument = pdfDocument;
        this.font = PdfFontFactory.createFont(StandardFonts.HELVETICA);
        this.logoImage = new Image(ImageDataFactory.create("src/main/resources/logo3.png"));
        
    }

    @Override
    public void handleEvent(Event event) {
    	
    	
        PdfDocumentEvent documentEvent = (PdfDocumentEvent) event;
        PdfDocument pdfDoc = documentEvent.getDocument();
        PdfPage page = documentEvent.getPage();
        int pageNumber = pdfDoc.getPageNumber(page);
        int totalNumberOfPages = pdfDoc.getNumberOfPages();
        
//        PdfDictionary pageDict = pdfDoc.getPage(2).getPdfObject();
//        pageDict.put(PdfName.MediaBox, new PdfArray(new float[]{36, 36, pdfDoc.getDefaultPageSize().getWidth() - 36, pdfDoc.getDefaultPageSize().getHeight() - 36}));
//    	
        	System.out.println(pageNumber);
	            
	            if (pageNumber > 1) {
	            	
//	            	PdfDictionary pageDict = pdfDoc.getPage(1).getPdfObject();
//	                pageDict.put(PdfName.MediaBox, new PdfArray(new float[]{36, 36, pdfDoc.getDefaultPageSize().getWidth() - 36, pdfDoc.getDefaultPageSize().getHeight() - 36}));

	            	
	            	 Document doc = new Document(pdfDocument);
	            	 
	            	// Create a canvas for the page
			        PdfCanvas canvas = new PdfCanvas(page);
			
			     // Add the logo image to the header
		            logoImage.scaleToFit(200, 200);
		            float x = page.getPageSize().getWidth() - 230;
		            float y = page.getPageSize().getHeight() - 67;
		            logoImage.setFixedPosition(x, y);
//		            documentEvent.getPage().getDocument().add(logoImage);
		            doc.add(logoImage);
		            
			        // Set the font and text properties
			        canvas.beginText()
			                .setFontAndSize(font, 10)
			                .moveText(570, 6)
			                .showText("" + pageNumber)
			                .endText();

			        // Draw a horizontal line in the footer
		            float footerY = 5;
		            float lineStartX = 20;
		            float lineEndX = page.getPageSize().getWidth() - 20;
		            canvas.setStrokeColor(ColorConstants.GRAY)
		                    .setLineWidth(0.5f)
		                    .moveTo(lineStartX, footerY)
		                    .lineTo(lineEndX, footerY)
		                    .stroke();
//			        canvas.stroke();
			
			        // Release the canvas
			        canvas.release();
			    }
	            pageNumber++;

    	}
    
    
    
}
