package com.velocityTemplate.InterViewPDF;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import com.itextpdf.layout.element.Paragraph;
//import com.itextpdf.layout.properties.AreaBreakType;
import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.events.IEventHandler;
import com.itextpdf.kernel.events.PdfDocumentEvent;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.AreaBreak;
//import com.itextpdf.layout.property.AreaBreakType;

public class PdfConverter{

    public ByteArrayOutputStream convertToPdf(String htmlContent) {
    
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    	PdfWriter writer = new PdfWriter(outputStream);
        PdfDocument pdf = new PdfDocument(writer);


        try {

//			document = new Document(pdf);
//			pdf.setMargins(10, 5, 10, 5);
        	
//        	HeaderFooter eventHandler = new HeaderFooter();
//        	pdf.addEventHandler(PdfDocumentEvent.START_PAGE, (IEventHandler) eventHandler);
//			document.add(new AreaBreak(AreaBreakType.NEXT_AREA));
////	        document.add(new Paragraph("Template: " + templateName));
//	        document.add(new Paragraph("Generated on: " + new Date().toString()));
			
        ConverterProperties converterProperties = new ConverterProperties();
//        
//    	pdf.addEventHandler(PdfDocumentEvent.START_PAGE, new HeaderFooter(headerContent, footerContent));
//        converterProperties.setBaseUri(document.toString());
        HtmlConverter.convertToPdf(htmlContent, pdf, converterProperties);

        
 
        return outputStream;
        }catch (Exception e) {
        	e.printStackTrace();
			return null;
		}
    }
    
}
