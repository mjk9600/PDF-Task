package com.velocityTemplate.InterViewPDF.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.velocityTemplate.InterViewPDF.model.FormModel;
import com.velocityTemplate.InterViewPDF.service.PdfService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class FormController {

	private final PdfService pdfService;

    @Autowired
    public FormController(PdfService pdfService) {
        this.pdfService = pdfService;
    }

    @PostMapping(value = "/generate-pdf", produces = MediaType.APPLICATION_PDF_VALUE)
    public HttpEntity<byte[]>  generatePdf(@RequestBody FormModel formValues) throws Exception {
        try {
        		
        	HttpEntity<byte[]> baos;
//        	JSONPObject object =new JSONPObject();
           baos= pdfService.createPdf(formValues);
//            redirectAttributes.addFlashAttribute("message", "PDF generated successfully");
            return baos;
//            System.out.println("its genetared");
            
        } catch (IOException e) {
//            redirectAttributes.addFlashAttribute("error", "Error generating PDF");
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
//        return "redirect:/";

    }
}
