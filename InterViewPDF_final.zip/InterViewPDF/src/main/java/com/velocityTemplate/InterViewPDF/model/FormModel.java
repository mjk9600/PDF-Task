package com.velocityTemplate.InterViewPDF.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class FormModel {

	 private String title;
	 private String search;
	 private String company;
	 private LocalDate  date;
	 private String publishBio;
	 private String mobile;
	 private String email;
	 private String education;
	 private String location;
	 private String notes1;
	 private String notes2;
	 
	 public FormModel(String title) {
			this.title = title;
		}
		
	 public FormModel(String title, String search, String company, LocalDate date, String publishBio, String mobile,
			String email, String education, String location, String notes1, String notes2) {
	
		this.title = title;
		this.search = search;
		this.company = company;
		this.date = date;
		this.publishBio = publishBio;
		this.mobile = mobile;
		this.email = email;
		this.education = education;
		this.location = location;
		this.notes1 = notes1;
		this.notes2 = notes2;
	}

	public String getDate() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM dd, yyyy");
		return date.format(formatter);
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getPublishBio() {
		return publishBio;
	}

	public void setPublishBio(String publishBio) {
		this.publishBio = publishBio;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getNotes1() {
		return notes1;
	}

	public void setNotes1(String notes1) {
		this.notes1 = notes1;
	}

	public String getNotes2() {
		return notes2;
	}

	public void setNotes2(String notes2) {
		this.notes2 = notes2;
	}
	
	 
	 
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSearch() {
		return search;
	}
	public void setSearch(String search) {
		this.search = search;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	
}
