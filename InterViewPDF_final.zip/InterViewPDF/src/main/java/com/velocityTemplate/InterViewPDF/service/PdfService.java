package com.velocityTemplate.InterViewPDF.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.kernel.events.PdfDocumentEvent;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.utils.PdfMerger;

import com.velocityTemplate.InterViewPDF.PageNumberEventHandler;
import com.velocityTemplate.InterViewPDF.model.FormModel;

@Service
public class PdfService {

	
//    private final VelocityEngine velocityEngine;

//    @Autowired
//    public PdfService(VelocityEngine velocityEngine) {
//        this.velocityEngine = velocityEngine;
//    }
//    
    
	public HttpEntity<byte[]>createPdf(FormModel formModel) throws Exception {
        // Initialize Velocity Engine
		 List<Template> templates = new ArrayList<>();
		 
		 
		
        VelocityEngine velocityEngine = new VelocityEngine();
        
        velocityEngine.setProperty(RuntimeConstants.RESOURCE_LOADER,"classpath");
        velocityEngine.setProperty("classpath.resource.loader.class",
				ClasspathResourceLoader.class.getName());
        velocityEngine.init();

        // Create Velocity Context
        VelocityContext velocityContext = new VelocityContext();
        velocityContext.put("title", "Hello, World!");
        velocityContext.put("content", "This is a sample Velocity template converted to PDF using iTextPDF.");

        // Merge template with context
      
//        Template template = velocityEngine.getTemplate("templates/helloWorld.vm");
        Template template1 = velocityEngine.getTemplate("templates/index.vm");
        Template template2 = velocityEngine.getTemplate("templates/page1.vm");
        Template template3 = velocityEngine.getTemplate("templates/page4.vm");
        Template template4 = velocityEngine.getTemplate("templates/page5.vm"); 
        Template template5 = velocityEngine.getTemplate("templates/page7.vm"); 
//        templates.add(template);
        templates.add(template1);
        templates.add(template2);
        templates.add(template3);
        templates.add(template4);
        templates.add(template5);
//        template.merge(velocityContext, writer);

        // Convert to PDF using iTextPDF
   
//        byte[] pdfBytes = converter.convertToPdf(writer.toString());

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
//		baos = converter.convertToPdf(writer.toString());
		baos = genPdf(templates,formModel);
        
        HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_PDF);
		header.set(HttpHeaders.CONTENT_DISPOSITION,"attachment: filename=");
		header.setContentLength(baos.toByteArray().length);
        
        return new HttpEntity<byte[]>(baos.toByteArray(),header);
    }

	
	public ByteArrayOutputStream genPdf(List<Template> templates ,FormModel formModel) throws IOException {
		 
		VelocityContext context = new VelocityContext();
		context.put("title", formModel.getTitle());
		context.put("company", formModel.getCompany());
		context.put("search", formModel.getSearch());
		context.put("date", formModel.getDate());
		context.put("bio", formModel.getPublishBio());
		context.put("mobile", formModel.getMobile());
		context.put("email", formModel.getEmail());
		context.put("location", formModel.getLocation());
		context.put("notes1", formModel.getNotes1());
		context.put("notes2", formModel.getNotes2());
		context.put("education", formModel.getEducation());
		
		
		System.out.println(formModel.getTitle());
		
		
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		ConverterProperties properties = new ConverterProperties();
		
	    PdfWriter writer = new PdfWriter(outputStream);
	    PdfDocument pdf = new PdfDocument(writer);

	    PdfMerger merger = new PdfMerger(pdf);
	    
	    PageNumberEventHandler pageNumberEventHandler = new PageNumberEventHandler(pdf);

	    pdf.addEventHandler(PdfDocumentEvent.END_PAGE,pageNumberEventHandler);
	    
	   
	

	    for (Template template : templates) {
	    	
	    	
		        StringWriter w = new StringWriter();
		        template.merge(context, w);
		        String html1 = w.toString();
	    
	        ByteArrayOutputStream baos = new ByteArrayOutputStream();
	        PdfDocument temp = new PdfDocument(new PdfWriter(baos));
	        HtmlConverter.convertToPdf(html1, temp, properties);
	        
	        
	        temp = new PdfDocument(
	            new PdfReader(new ByteArrayInputStream(baos.toByteArray())));
	        merger.merge(temp, 1, temp.getNumberOfPages());
	        temp.close();
	    }
	    
	    pdf.close();
	    
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String timestamp = dateFormat.format(new Date());
        String fileName = "generated_" + timestamp + ".pdf";

        // Save the PDF file to the specific folder with the unique file name
        String outputPath = "/home/mukesh/Documents/" + fileName;
        FileOutputStream fos = new FileOutputStream(outputPath);
        fos.write(outputStream.toByteArray());
        fos.close(); 
        
	    return outputStream;
		
		}
}
