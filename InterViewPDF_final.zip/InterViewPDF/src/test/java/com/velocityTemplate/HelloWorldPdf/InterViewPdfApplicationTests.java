package com.velocityTemplate.HelloWorldPdf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterViewPdfApplicationTests {

	@Test
	void contextLoads() {
	}

}
